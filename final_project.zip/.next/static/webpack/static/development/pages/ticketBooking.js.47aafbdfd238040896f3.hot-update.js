webpackHotUpdate("static\\development\\pages\\ticketBooking.js",{

/***/ "./pages/ticketBooking.js":
/*!********************************!*\
  !*** ./pages/ticketBooking.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/es/index.js");
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-datepicker */ "./node_modules/react-datepicker/es/index.js");
/* harmony import */ var sort_json_array__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! sort-json-array */ "./node_modules/sort-json-array/index.js");
/* harmony import */ var sort_json_array__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(sort_json_array__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-tooltip */ "./node_modules/react-tooltip/dist/index.js");
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_tooltip__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! dateformat */ "./node_modules/dateformat/lib/dateformat.js");
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(dateformat__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var currency_symbol_map__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! currency-symbol-map */ "./node_modules/currency-symbol-map/currency-symbol-map.js");
/* harmony import */ var currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(currency_symbol_map__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var datetime_difference__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! datetime-difference */ "./node_modules/datetime-difference/index.js");
/* harmony import */ var datetime_difference__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(datetime_difference__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! isomorphic-fetch */ "./node_modules/isomorphic-fetch/fetch-npm-browserify.js");
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../api */ "./api/index.js");
/* harmony import */ var react_autosuggest__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! react-autosuggest */ "./node_modules/react-autosuggest/dist/index.js");
/* harmony import */ var react_autosuggest__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_autosuggest__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! autosuggest-highlight/match */ "./node_modules/autosuggest-highlight/match/index.js");
/* harmony import */ var autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! autosuggest-highlight/parse */ "./node_modules/autosuggest-highlight/parse/index.js");
/* harmony import */ var autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_26__);











var _jsxFileName = "D:\\react projects\\flight_ticket\\pages\\ticketBooking.js",
    _this2 = undefined;













 //Auto complete imports




 // Auto complete

var languages = __webpack_require__(/*! ../data/countries.json */ "./data/countries.json");

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getSuggestions(value) {
  console.log("Get suggestions", value);
  var escapedValue = escapeRegexCharacters(value.trim());

  if (escapedValue === '') {
    return [];
  }

  var regex = new RegExp('^' + escapedValue, 'i');
  return languages.filter(function (language) {
    return regex.test(language.CityName);
  });
}

function getSuggestionValue(suggestion) {
  console.log("Get suggestions value", suggestion);
  return "".concat(suggestion.CityName, " - ").concat(suggestion.PlaceName, " (").concat(suggestion.PlaceId, ")");
}

function renderSuggestion(suggestion, _ref) {
  var query = _ref.query;
  var suggestionText = "".concat(suggestion.CityName, " - ").concat(suggestion.PlaceName, " (").concat(suggestion.PlaceId, ")");
  var suggestionCountry = "".concat(suggestion.CountryId);
  var matches = autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24___default()(suggestionText, query);
  var parts = autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25___default()(suggestionText, matches);
  return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: 'suggestion-content ' + suggestion.twitter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "autocomplete-name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
    className: "fa fa-fighter-jet autocomplete-flight-img",
    alt: "Flight",
    src: "static/images/flight.png",
    width: "25px",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), parts.map(function (part, index) {
    var className = part.highlight ? 'highlight' : null;
    return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: className,
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 58
      },
      __self: this
    }, part.text);
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "country-name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }, suggestionCountry)));
}

var MyAutosuggest =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__["default"])(MyAutosuggest, _React$Component);

  function MyAutosuggest(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, MyAutosuggest);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(MyAutosuggest).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onChange", function (_, _ref2) {
      var newValue = _ref2.newValue;
      var _this$props = _this.props,
          id = _this$props.id,
          onChange = _this$props.onChange;

      _this.setState({
        value: newValue
      });

      onChange(id, newValue);
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onSuggestionsFetchRequested", function (_ref3) {
      var value = _ref3.value;
      console.log("fetch requetsed", value);

      _this.setState({
        suggestions: getSuggestions(value)
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onSuggestionsClearRequested", function () {
      _this.setState({
        suggestions: []
      });
    });

    _this.state = {
      value: _this.props.value,
      suggestions: ["name"]
    };
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__["default"])(MyAutosuggest, [{
    key: "render",
    value: function render() {
      var _this$props2 = this.props,
          id = _this$props2.id,
          placeholder = _this$props2.placeholder;
      var _this$state = this.state,
          value = _this$state.value,
          suggestions = _this$state.suggestions;
      var inputProps = {
        placeholder: placeholder,
        value: value,
        onChange: this.onChange
      };
      return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_autosuggest__WEBPACK_IMPORTED_MODULE_23___default.a, {
        id: id,
        suggestions: suggestions,
        onSuggestionsFetchRequested: this.onSuggestionsFetchRequested,
        onSuggestionsClearRequested: this.onSuggestionsClearRequested,
        getSuggestionValue: getSuggestionValue,
        renderSuggestion: renderSuggestion,
        inputProps: inputProps,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 109
        },
        __self: this
      });
    }
  }]);

  return MyAutosuggest;
}(react__WEBPACK_IMPORTED_MODULE_10___default.a.Component);

var TicketBooking = function TicketBooking(flights) {
  var requestData = {
    "adultCount": "1",
    "childCount": "0",
    "infantCount": "0",
    "isDirectFlight": "false",
    "isPlusOrMinus3Days": "false",
    "searchType": "2",
    "preferedFlightClass": "1",
    "segments": [{
      "departureLocationCode": "LON",
      "departureDate": "20-10-2019",
      "arrivalLocationCode": "DEL",
      "returnDate": "26-10-2019",
      "departureTime": "Any",
      "returnTime": "Any"
    }],
    "paging": {
      "PageIndex": "1",
      "PageSize": "50"
    },
    "departureLocationName": "London",
    "arrivalLocationName": "colombo"
  };
  console.log("Flights: ", flights.flights);
  console.log("REquest: ", flights.request); // State initialisation
  //const [requestData,setRequestData] = useState([]);

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])([]),
      _useState2 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      jsondata = _useState2[0],
      setJsondata = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(new Date()),
      _useState4 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState3, 2),
      startDate = _useState4[0],
      setStartDate = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(new Date()),
      _useState6 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState5, 2),
      endDate = _useState6[0],
      setEndDate = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(requestData.departureLocationName),
      _useState8 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState7, 2),
      sourcePlace = _useState8[0],
      setSourcePlace = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(requestData.arrivalLocationName),
      _useState10 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState9, 2),
      destinationPlace = _useState10[0],
      setDestinationPlace = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(false),
      _useState12 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState11, 2),
      sortToggler = _useState12[0],
      setSortToggler = _useState12[1];

  var _useState13 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(false),
      _useState14 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState13, 2),
      filterToggler = _useState14[0],
      setFilterToggler = _useState14[1];

  var _useState15 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])('Best'),
      _useState16 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState15, 2),
      sortOption = _useState16[0],
      setSortOption = _useState16[1]; // useEffect(() => {
  //     console.log("Axios call");
  //     fetch(url)
  //     //     {
  //     //     method: 'POST', 
  //     //     // headers: {
  //     //     //   'Authorization': 'Basic 0b017b0c0d414e20ee0d2e4adbed686d7c297a6d2f8ec8f9eddc2016d9513482a086fe8712ef0530',
  //     //     //   'content-Type': 'application/json'
  //     //     // },
  //     //     //body: JSON.stringify(requestData)
  //     //   })
  //     .then(response => console.log(response.data));
  // });


  var handleChange = function handleChange(date) {
    setStartDate(date);
  };

  var handleChange1 = function handleChange1(date) {
    setEndDate(date);
  };

  var changePlace = function changePlace(e) {
    setSourcePlace(destinationPlace);
    setDestinationPlace(sourcePlace);
  };

  var changeMonthDate = function changeMonthDate(dt) {
    var date1 = dt.split('-');
    var newDate = date1[1] + '-' + date1[0] + '-' + date1[2];
    var date = new Date(newDate);
    return date;
  };

  var TimeSplit = function TimeSplit(time) {
    time = time.replace(/(..?)/g, '$1:').slice(0, -1);
    return time;
  };

  var handlesortToggler = function handlesortToggler() {
    setSortToggler(true);
    setFilterToggler(false);
  };

  var handleFilterToggler = function handleFilterToggler() {
    setFilterToggler(true);
    setSortToggler(false);
  };

  var handleScrollToElement = function handleScrollToElement(event) {
    $(window).scroll(function () {
      var sticky = $('.filtering-row.row'),
          scroll = $(window).scrollTop();
      if (scroll >= 400) sticky.addClass('fixed');else sticky.removeClass('fixed');
    });
  };

  var StopName = function StopName(stop) {
    if (stop == 0) {
      return "Non-stop";
    } else if (stop == 1) {
      return "1 stop";
    } else if (stop == 2) {
      return "2 stops";
    }
  };

  var StopClassName = function StopClassName(stop) {
    if (stop == 1) {
      return "onestop";
    } else if (stop == 2) {
      return "twostop";
    }
  };

  var CalculateDuration = function CalculateDuration(duration) {
    duration = TimeSplit(duration);
    var duration1 = duration.split(":");
    var duration_str = duration1[0] + "h " + duration1[1] + "m";
    return duration_str;
  };

  var ViaCityName = function ViaCityName(cityname) {
    cityname = cityname.split("(");
    return cityname[0];
  };

  var fastestDuration = function fastestDuration() {
    var fastest_duration = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.flightLeg[0].flightDetails.totalFlyingHours;
    }));
    console.log(fastest_duration);
    return CalculateDuration(fastest_duration.toString());
  };

  var fastestPrice = function fastestPrice() {
    var fastest_duration = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.flightLeg[0].flightDetails.totalFlyingHours;
    }));
    var fastest_price = jsondata.recommendation.filter(function (price) {
      return price.flightLeg[0].flightDetails.totalFlyingHours == fastest_duration;
    });
    fastest_price = fastest_price[0].totalFare;
    return fastest_price;
  };

  var cheapestDuration = function cheapestDuration() {
    console.log("Cheapest: ", jsondata);
    var cheapest_price = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.totalFare;
    }));
    var cheapest_duration = jsondata.recommendation.filter(function (price) {
      return price.totalFare == cheapest_price;
    });
    cheapest_duration = cheapest_duration[0].flightLeg[0].flightDetails.totalFlyingHours;
    return CalculateDuration(cheapest_duration);
  };

  var cheapestPrice = function cheapestPrice() {
    var cheapest_price = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.totalFare;
    }));
    return cheapest_price;
  };

  var bestDuration = function bestDuration() {
    var best_price = jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    });
    return CalculateDuration(best_price[0].flightLeg[0].flightDetails.totalFlyingHours);
  };

  var bestPrice = function bestPrice() {
    var best_price = jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    });
    return best_price[0].totalFare;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(function () {
    window.addEventListener('scroll', handleScrollToElement);
  });

  var handleSortOptions = function handleSortOptions(e) {
    setSortOption(e.target.value);

    if (e.target.value === "Best") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
      }));
    } else if (e.target.value === "Cheapest First") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.totalFare - obj2.totalFare;
      }));
    } else if (e.target.value === "Fastest First") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
      }));
    } else if (e.target.value === "Outbound: Departure Time") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.departureTime - obj2.flightLeg[0].flightDetails.departureTime;
      }));
    } else if (e.target.value === "Airline") {
      setJsondata(sort_json_array__WEBPACK_IMPORTED_MODULE_14___default()(jsondata.recommendation, "marketingAirlineNames", "asc"));
    } else if (e.target.value === "Stops") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.stopOvers - obj2.flightLeg[0].flightDetails.stopOvers;
      }));
    }
  };

  var handleSortBest = function handleSortBest(e) {
    setSortOption("Best");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    }));
  };

  var handleSortCheapest = function handleSortCheapest(e) {
    setSortOption("Cheapest First");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare;
    }));
  };

  var handleSortFastest = function handleSortFastest(e) {
    setSortOption("Fastest First");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    }));
  };

  var filtercname = function filtercname(text) {
    var filter_text = text.trim();
    filter_text = filter_text.split("-");
    return filter_text[0];
  };

  var preferedclassname = function preferedclassname(classname) {
    if (classname == "1") {
      return "Any";
    } else if (classname == "2") {
      return "Business";
    } else if (classname == "3") {
      return "Economy";
    } else if (classname == "4") {
      return "First Class";
    } else if (classname == "5") {
      return "PremiumOrEconomy";
    } else if (classname == "6") {
      return "PremiumAndEconomy";
    }
  };

  var nonstopFlights = function nonstopFlights() {
    console.log("working");
    console.log(jsondata);
    console.log(jsondata.recommendation.filter(function (newdata) {
      return newdata.flightLeg[0].flightDetails.stopOvers == 0;
    }));
    console.log(jsondata);
  };

  var onChangeHome = function onChangeHome(id, suggestion, value) {
    console.log("onahnbeg vaue: ", value);

    if (id == "countries1") {
      var suggestion = suggestion.trim(); // setDepartureLocationName(suggestion);

      var length = suggestion.length;
      var exact_match = suggestion.substring(length - 4, length - 1);
      exact_match = exact_match.trim(); // setDeparturelocationcode(exact_match);
    } else if (id == "countries2") {
      var suggestion = suggestion.trim(); // setArrivalLocationName(suggestion);

      var length = suggestion.length;
      var exact_match = suggestion.substring(length - 4, length - 1);
      exact_match = exact_match.trim(); // setArrivallocationcode(exact_match);
    }
  }; // var currencyCode = jsondata.currencyCode;
  // var total_response = jsondata.recommendation.length;


  var currencyCode = "E";
  var total_response = 50; // console.log(Object.keys(flights).length);

  return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(_components_layout__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 420
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "container-fluid",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 421
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "bg-img",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 422
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "margin-0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 423
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    style: {
      padding: '0'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 424
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-details",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 425
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 426
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xl: 3,
    lg: 4,
    md: 6,
    sm: 8,
    xs: 9,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 427
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 428
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 5,
    xs: 5,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 429
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-class",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 430
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text absl-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 431
    },
    __self: this
  }, "TRIP TYPE"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Control, {
    className: "trip_select",
    as: "select",
    defaultValue: requestData.searchType,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 432
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "1",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 433
    },
    __self: this
  }, "One Way"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "2",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 434
    },
    __self: this
  }, "Round Trip"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "3",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 435
    },
    __self: this
  }, "Multi-city")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-sort-desc",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 437
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 7,
    xs: 7,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 440
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-class",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 441
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text absl-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 442
    },
    __self: this
  }, "Passanger & Class"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 443
    },
    __self: this
  }, requestData.adultCount, " Adult, ", preferedclassname(requestData.preferedFlightClass)))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xl: 9,
    lg: 8,
    md: 6,
    sm: 4,
    xs: 3,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 450
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 453
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 6,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 454
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 455
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 6,
    sm: 6,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 456
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Group, {
    className: "auto_countries",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 457
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 458
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Prepend, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 459
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Text, {
    id: "inputGroupPrepend",
    className: "bluebg-igroup",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 460
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-map-marker",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 460
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(MyAutosuggest, {
    id: "countries1",
    onChange: onChangeHome,
    value: "Chennai",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 470
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-exchange",
    "aria-hidden": "true",
    onClick: changePlace,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 473
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 6,
    sm: 6,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 475
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Group, {
    className: "auto_countries",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 476
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 477
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Prepend, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 478
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Text, {
    id: "inputGroupPrepend",
    className: "bluebg-igroup",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 479
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-map-marker",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 479
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(MyAutosuggest, {
    id: "countries2",
    onChange: onChangeHome,
    value: "Mumbai",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 489
    },
    __self: this
  })))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 6,
    className: "padding-col",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 495
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 496
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 8,
    md: 8,
    sm: 9,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 497
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "dis_flex",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 498
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "calendar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 499
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
    className: "img_calendar",
    src: "static/images/calendar.svg",
    width: "25",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 500
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_datepicker__WEBPACK_IMPORTED_MODULE_13__["default"], {
    name: "departureDate",
    className: "form-control",
    showMonthDropdown: true,
    showYearDropdown: true,
    dateFormat: "eee, MMM d",
    selected: startDate,
    onChange: handleChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 501
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "separt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 511
    },
    __self: this
  }, " | ")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "calendar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 513
    },
    __self: this
  }, "\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_datepicker__WEBPACK_IMPORTED_MODULE_13__["default"], {
    name: "departureDate",
    className: "form-control",
    showMonthDropdown: true,
    showYearDropdown: true,
    dateFormat: "eee, MMM d",
    selected: endDate,
    onChange: handleChange1,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 514
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 4,
    md: 4,
    sm: 3,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 527
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("button", {
    className: "btn-search",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 528
    },
    __self: this
  }, "SEARCH"))))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "mobile-filterscreen",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 539
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "visible-xs filter-mobile",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 540
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "filtering-row",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 541
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 6,
    xs: 6,
    lg: 6,
    style: {
      borderRight: '1px solid #FF4057'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 542
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    onClick: handlesortToggler,
    className: "mob-togglehead",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 543
    },
    __self: this
  }, "Sort ")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 6,
    xs: 6,
    lg: 6,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 545
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    onClick: handleFilterToggler,
    className: "mob-togglehead",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 546
    },
    __self: this
  }, "Filter "))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    style: {
      position: 'relative'
    },
    hidden: !sortToggler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 549
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "sort",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 550
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 12,
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 551
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 552
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "bold-text",
    style: {
      fontSize: '13px'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 553
    },
    __self: this
  }, "Sort by:"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Button"], {
    variant: "outline-danger",
    style: {
      "float": 'right'
    },
    onClick: function onClick() {
      return _this2.setState({
        sortToggler: false,
        filterToggler: false
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 554
    },
    __self: this
  }, "Close")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("ul", {
    className: "mobile-sortlist",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 556
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 557
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 558
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Popularity",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 559
    },
    __self: this
  }), " Popularity")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 562
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 563
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Duration",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 564
    },
    __self: this
  }), " Duration")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 567
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 568
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Price",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 569
    },
    __self: this
  }), " Price"))))))), filterToggler ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "datas",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 579
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 580
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 581
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 582
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "bold-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 583
    },
    __self: this
  }, "Filter by:"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Button"], {
    variant: "outline-danger",
    style: {
      "float": 'right'
    },
    onClick: function onClick() {
      setSortToggler(false);
      setFilterToggler(false);
      setFilterToggler(false);
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 584
    },
    __self: this
  }, "Done")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 586
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 587
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 588
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 589
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 590
    },
    __self: this
  }, "Stops")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 593
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 594
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 595
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Non-stop",
    name: "stop1",
    value: "Non-stop",
    onClick: nonstopFlights,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 596
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "1stop",
    name: "stop2",
    value: "1stop",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 597
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "2 Stops",
    name: "stop3",
    value: "2stops",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 598
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 603
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 604
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 605
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 605
    },
    __self: this
  }, filtercname(requestData.departureLocationName)))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 608
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 609
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 610
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 611
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 612
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 613
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 618
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 619
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 620
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 620
    },
    __self: this
  }, filtercname(requestData.arrivalLocationName)))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 623
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 624
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 625
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 626
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 627
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 628
    },
    __self: this
  }))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 635
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 636
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 637
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 638
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 639
    },
    __self: this
  }, "Airlines"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 642
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 643
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 644
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 645
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Lingus(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 646
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Alitalia(6) 86,227",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 647
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Finance(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 648
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "American Airlines,102,750",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 649
    },
    __self: this
  }))))))))) : null), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter-data",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 666
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "container-fluid",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 667
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 668
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 10,
    xl: 10,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 669
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 670
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 3,
    className: "hidden-xs",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 672
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 673
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 674
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 675
    },
    __self: this
  }, "Stops"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 676
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 681
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 682
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 683
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Non-stop",
    name: "stop1",
    value: "Non-stop",
    onClick: nonstopFlights,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 684
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "1 Stop",
    name: "stop2",
    value: "1stop",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 685
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "2 Stops",
    name: "stop3",
    value: "2stops",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 686
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 691
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 692
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 693
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 693
    },
    __self: this
  }, filtercname(requestData.departureLocationName))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 694
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 698
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 699
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 700
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6 AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 701
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 702
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 703
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 708
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 709
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 710
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 710
    },
    __self: this
  }, filtercname(requestData.arrivalLocationName))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 711
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 715
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 716
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 717
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6 AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 718
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 719
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 725
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 726
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 727
    },
    __self: this
  }, "Airlines"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 728
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 732
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 733
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 734
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Lingus(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 735
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Alitalia(6) 86,227",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 736
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Finance(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 737
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "American Airlines,102,750",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 738
    },
    __self: this
  })))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 2,
    xl: 2,
    className: "text-center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 751
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 752
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 753
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 754
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 755
    },
    __self: this
  }, "Place for ad"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 758
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 759
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 760
    },
    __self: this
  }, "Place for ad"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 763
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 764
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 765
    },
    __self: this
  }, "Place for ad"))))))))));
}; // TicketBooking.getInitialProps = ({ query: { departureLocationCode,arrivalLocationCode,departureDate,returnDate,isDirectFlight,searchType,adultCount,childCount,preferedFlightClass,departureTime,returnTime,departureLocationName,arrivalLocationName} }) => {
//     return { 
//         departureLocationCode: departureLocationCode, 
// 		arrivalLocationCode: arrivalLocationCode, 
//         departureDate: departureDate,
//         returnDate: returnDate,
//         isDirectFlight : isDirectFlight,
//         searchType: searchType,
//         adultCount: adultCount,
//         childCount: childCount,
//         preferedFlightClass: preferedFlightClass,
//         departureTime: "Any",
//         returnTime: "Any",
//         departureLocationName: departureLocationName,
//         arrivalLocationName: arrivalLocationName
//      }
//   }


TicketBooking.getInitialProps =
/*#__PURE__*/
function () {
  var _ref5 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref4) {
    var _ref4$query, adultCount, childCount, infantCount, isDirectFlight, isPlusOrMinus3Days, searchType, preferedFlightClass, departureLocationCode, departureDate, arrivalLocationCode, returnDate, departureTime, returnTime, PageIndex, PageSize, departureLocationName, arrivalLocationName, request, res, json;

    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _ref4$query = _ref4.query, adultCount = _ref4$query.adultCount, childCount = _ref4$query.childCount, infantCount = _ref4$query.infantCount, isDirectFlight = _ref4$query.isDirectFlight, isPlusOrMinus3Days = _ref4$query.isPlusOrMinus3Days, searchType = _ref4$query.searchType, preferedFlightClass = _ref4$query.preferedFlightClass, departureLocationCode = _ref4$query.departureLocationCode, departureDate = _ref4$query.departureDate, arrivalLocationCode = _ref4$query.arrivalLocationCode, returnDate = _ref4$query.returnDate, departureTime = _ref4$query.departureTime, returnTime = _ref4$query.returnTime, PageIndex = _ref4$query.PageIndex, PageSize = _ref4$query.PageSize, departureLocationName = _ref4$query.departureLocationName, arrivalLocationName = _ref4$query.arrivalLocationName;
            request = {
              "adultCount": adultCount,
              "childCount": childCount,
              "infantCount": infantCount,
              "isDirectFlight": isDirectFlight,
              "isPlusOrMinus3Days": isPlusOrMinus3Days,
              "searchType": searchType,
              "preferedFlightClass": preferedFlightClass,
              "segments": [{
                "departureLocationCode": departureLocationCode,
                "departureDate": departureDate,
                "arrivalLocationCode": arrivalLocationCode,
                "returnDate": returnDate,
                "departureTime": departureTime,
                "returnTime": returnTime
              }],
              "paging": {
                "PageIndex": PageIndex,
                "PageSize": PageSize
              }
            };
            _context.next = 4;
            return Object(_api__WEBPACK_IMPORTED_MODULE_22__["getFlights"])(request);

          case 4:
            res = _context.sent;
            _context.next = 7;
            return res;

          case 7:
            json = _context.sent;
            return _context.abrupt("return", {
              flights: json,
              request: {
                "adultCount": adultCount,
                "childCount": childCount,
                "infantCount": infantCount,
                "isDirectFlight": isDirectFlight,
                "isPlusOrMinus3Days": isPlusOrMinus3Days,
                "searchType": searchType,
                "preferedFlightClass": preferedFlightClass,
                "departureLocationName": departureLocationName,
                "arrivalLocationName": arrivalLocationName,
                "segments": [{
                  "departureLocationCode": departureLocationCode,
                  "departureDate": departureDate,
                  "arrivalLocationCode": arrivalLocationCode,
                  "returnDate": returnDate,
                  "departureTime": departureTime,
                  "returnTime": returnTime
                }],
                "paging": {
                  "PageIndex": PageIndex,
                  "PageSize": PageSize
                }
              }
            });

          case 9:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref5.apply(this, arguments);
  };
}();

/* harmony default export */ __webpack_exports__["default"] = (TicketBooking);

/***/ })

})
//# sourceMappingURL=ticketBooking.js.47aafbdfd238040896f3.hot-update.js.map