webpackHotUpdate("static\\development\\pages\\ticketBooking.js",{

/***/ "./pages/ticketBooking.js":
/*!********************************!*\
  !*** ./pages/ticketBooking.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/es/index.js");
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-datepicker */ "./node_modules/react-datepicker/es/index.js");
/* harmony import */ var sort_json_array__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! sort-json-array */ "./node_modules/sort-json-array/index.js");
/* harmony import */ var sort_json_array__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(sort_json_array__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-tooltip */ "./node_modules/react-tooltip/dist/index.js");
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_tooltip__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! dateformat */ "./node_modules/dateformat/lib/dateformat.js");
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(dateformat__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var currency_symbol_map__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! currency-symbol-map */ "./node_modules/currency-symbol-map/currency-symbol-map.js");
/* harmony import */ var currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(currency_symbol_map__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var datetime_difference__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! datetime-difference */ "./node_modules/datetime-difference/index.js");
/* harmony import */ var datetime_difference__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(datetime_difference__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! isomorphic-fetch */ "./node_modules/isomorphic-fetch/fetch-npm-browserify.js");
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../api */ "./api/index.js");
/* harmony import */ var react_autosuggest__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! react-autosuggest */ "./node_modules/react-autosuggest/dist/index.js");
/* harmony import */ var react_autosuggest__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_autosuggest__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! autosuggest-highlight/match */ "./node_modules/autosuggest-highlight/match/index.js");
/* harmony import */ var autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! autosuggest-highlight/parse */ "./node_modules/autosuggest-highlight/parse/index.js");
/* harmony import */ var autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_26__);











var _jsxFileName = "D:\\react projects\\flight_ticket\\pages\\ticketBooking.js",
    _this2 = undefined;













 //Auto complete imports




 // Auto complete

var languages = __webpack_require__(/*! ../data/countries.json */ "./data/countries.json");

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getSuggestions(value) {
  console.log("Get suggestions", value);
  var escapedValue = escapeRegexCharacters(value.trim());

  if (escapedValue === '') {
    return [];
  }

  var regex = new RegExp('^' + escapedValue, 'i');
  return languages.filter(function (language) {
    return regex.test(language.CityName);
  });
}

function getSuggestionValue(suggestion) {
  console.log("Get suggestions value", suggestion);
  return "".concat(suggestion.CityName, " - ").concat(suggestion.PlaceName, " (").concat(suggestion.PlaceId, ")");
}

function renderSuggestion(suggestion, _ref) {
  var query = _ref.query;
  var suggestionText = "".concat(suggestion.CityName, " - ").concat(suggestion.PlaceName, " (").concat(suggestion.PlaceId, ")");
  var suggestionCountry = "".concat(suggestion.CountryId);
  var matches = autosuggest_highlight_match__WEBPACK_IMPORTED_MODULE_24___default()(suggestionText, query);
  var parts = autosuggest_highlight_parse__WEBPACK_IMPORTED_MODULE_25___default()(suggestionText, matches);
  return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: 'suggestion-content ' + suggestion.twitter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "autocomplete-name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
    className: "fa fa-fighter-jet autocomplete-flight-img",
    alt: "Flight",
    src: "static/images/flight.png",
    width: "25px",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), parts.map(function (part, index) {
    var className = part.highlight ? 'highlight' : null;
    return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: className,
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 58
      },
      __self: this
    }, part.text);
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "country-name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }, suggestionCountry)));
}

var MyAutosuggest =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__["default"])(MyAutosuggest, _React$Component);

  function MyAutosuggest(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, MyAutosuggest);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(MyAutosuggest).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onChange", function (_, _ref2) {
      var newValue = _ref2.newValue;
      var _this$props = _this.props,
          id = _this$props.id,
          onChange = _this$props.onChange;

      _this.setState({
        value: newValue
      });

      onChange(id, newValue);
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onSuggestionsFetchRequested", function (_ref3) {
      var value = _ref3.value;
      console.log("fetch requetsed", value);

      _this.setState({
        suggestions: getSuggestions(value)
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__["default"])(_this), "onSuggestionsClearRequested", function () {
      _this.setState({
        suggestions: []
      });
    });

    _this.state = {
      value: _this.props.value,
      suggestions: ["name"]
    };
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__["default"])(MyAutosuggest, [{
    key: "render",
    value: function render() {
      var _this$props2 = this.props,
          id = _this$props2.id,
          placeholder = _this$props2.placeholder;
      var _this$state = this.state,
          value = _this$state.value,
          suggestions = _this$state.suggestions;
      var inputProps = {
        placeholder: placeholder,
        value: value,
        onChange: this.onChange
      };
      return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_autosuggest__WEBPACK_IMPORTED_MODULE_23___default.a, {
        id: id,
        suggestions: suggestions,
        onSuggestionsFetchRequested: this.onSuggestionsFetchRequested,
        onSuggestionsClearRequested: this.onSuggestionsClearRequested,
        getSuggestionValue: getSuggestionValue,
        renderSuggestion: renderSuggestion,
        inputProps: inputProps,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 109
        },
        __self: this
      });
    }
  }]);

  return MyAutosuggest;
}(react__WEBPACK_IMPORTED_MODULE_10___default.a.Component);

var TicketBooking = function TicketBooking(flights) {
  console.log("Flights: ", flights.flights.data);
  console.log("REquest: ", flights.request);
  console.log(new Date(requestData.departureDate)); // State initialisation

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(flights.request),
      _useState2 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      requestData = _useState2[0],
      setRequestData = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(flights.flights.data),
      _useState4 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState3, 2),
      jsondata = _useState4[0],
      setJsondata = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(new Date()),
      _useState6 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState5, 2),
      startDate = _useState6[0],
      setStartDate = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(new Date()),
      _useState8 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState7, 2),
      endDate = _useState8[0],
      setEndDate = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(requestData.departureLocationName),
      _useState10 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState9, 2),
      sourcePlace = _useState10[0],
      setSourcePlace = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(requestData.arrivalLocationName),
      _useState12 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState11, 2),
      destinationPlace = _useState12[0],
      setDestinationPlace = _useState12[1];

  var _useState13 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(false),
      _useState14 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState13, 2),
      sortToggler = _useState14[0],
      setSortToggler = _useState14[1];

  var _useState15 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])(false),
      _useState16 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState15, 2),
      filterToggler = _useState16[0],
      setFilterToggler = _useState16[1];

  var _useState17 = Object(react__WEBPACK_IMPORTED_MODULE_10__["useState"])('Best'),
      _useState18 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState17, 2),
      sortOption = _useState18[0],
      setSortOption = _useState18[1];

  var handleChange = function handleChange(date) {
    setStartDate(date);
  };

  var handleChange1 = function handleChange1(date) {
    setEndDate(date);
  };

  var changePlace = function changePlace(e) {
    setSourcePlace(destinationPlace);
    setDestinationPlace(sourcePlace);
  };

  var changeMonthDate = function changeMonthDate(dt) {
    var date1 = dt.split('-');
    var newDate = date1[1] + '-' + date1[0] + '-' + date1[2];
    var date = new Date(newDate);
    return date;
  };

  var TimeSplit = function TimeSplit(time) {
    time = time.replace(/(..?)/g, '$1:').slice(0, -1);
    return time;
  };

  var handlesortToggler = function handlesortToggler() {
    setSortToggler(true);
    setFilterToggler(false);
  };

  var handleFilterToggler = function handleFilterToggler() {
    setFilterToggler(true);
    setSortToggler(false);
  };

  var handleScrollToElement = function handleScrollToElement(event) {
    $(window).scroll(function () {
      var sticky = $('.filtering-row.row'),
          scroll = $(window).scrollTop();
      if (scroll >= 400) sticky.addClass('fixed');else sticky.removeClass('fixed');
    });
  };

  var StopName = function StopName(stop) {
    if (stop == 0) {
      return "Non-stop";
    } else if (stop == 1) {
      return "1 stop";
    } else if (stop == 2) {
      return "2 stops";
    }
  };

  var StopClassName = function StopClassName(stop) {
    if (stop == 1) {
      return "onestop";
    } else if (stop == 2) {
      return "twostop";
    }
  };

  var CalculateDuration = function CalculateDuration(duration) {
    duration = TimeSplit(duration);
    var duration1 = duration.split(":");
    var duration_str = duration1[0] + "h " + duration1[1] + "m";
    return duration_str;
  };

  var ViaCityName = function ViaCityName(cityname) {
    cityname = cityname.split("(");
    return cityname[0];
  };

  var fastestDuration = function fastestDuration() {
    var fastest_duration = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.flightLeg[0].flightDetails.totalFlyingHours;
    }));
    console.log(fastest_duration);
    return CalculateDuration(fastest_duration.toString());
  };

  var fastestPrice = function fastestPrice() {
    var fastest_duration = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.flightLeg[0].flightDetails.totalFlyingHours;
    }));
    var fastest_price = jsondata.recommendation.filter(function (price) {
      return price.flightLeg[0].flightDetails.totalFlyingHours == fastest_duration;
    });
    fastest_price = fastest_price[0].totalFare;
    return fastest_price;
  };

  var cheapestDuration = function cheapestDuration() {
    console.log("Cheapest: ", jsondata);
    var cheapest_price = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.totalFare;
    }));
    var cheapest_duration = jsondata.recommendation.filter(function (price) {
      return price.totalFare == cheapest_price;
    });
    cheapest_duration = cheapest_duration[0].flightLeg[0].flightDetails.totalFlyingHours;
    return CalculateDuration(cheapest_duration);
  };

  var cheapestPrice = function cheapestPrice() {
    var cheapest_price = Math.min.apply(Math, jsondata.recommendation.map(function (o) {
      return o.totalFare;
    }));
    return cheapest_price;
  };

  var bestDuration = function bestDuration() {
    var best_price = jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    });
    return CalculateDuration(best_price[0].flightLeg[0].flightDetails.totalFlyingHours);
  };

  var bestPrice = function bestPrice() {
    var best_price = jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    });
    return best_price[0].totalFare;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_10__["useEffect"])(function () {
    window.addEventListener('scroll', handleScrollToElement);
  });

  var handleSortOptions = function handleSortOptions(e) {
    setSortOption(e.target.value);

    if (e.target.value === "Best") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
      }));
    } else if (e.target.value === "Cheapest First") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.totalFare - obj2.totalFare;
      }));
    } else if (e.target.value === "Fastest First") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
      }));
    } else if (e.target.value === "Outbound: Departure Time") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.departureTime - obj2.flightLeg[0].flightDetails.departureTime;
      }));
    } else if (e.target.value === "Airline") {
      setJsondata(sort_json_array__WEBPACK_IMPORTED_MODULE_14___default()(jsondata.recommendation, "marketingAirlineNames", "asc"));
    } else if (e.target.value === "Stops") {
      setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
        return obj1.flightLeg[0].flightDetails.stopOvers - obj2.flightLeg[0].flightDetails.stopOvers;
      }));
    }
  };

  var handleSortBest = function handleSortBest(e) {
    setSortOption("Best");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare && obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    }));
  };

  var handleSortCheapest = function handleSortCheapest(e) {
    setSortOption("Cheapest First");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.totalFare - obj2.totalFare;
    }));
  };

  var handleSortFastest = function handleSortFastest(e) {
    setSortOption("Fastest First");
    setJsondata(jsondata.recommendation.sort(function (obj1, obj2) {
      return obj1.flightLeg[0].flightDetails.totalFlyingHours - obj2.flightLeg[0].flightDetails.totalFlyingHours;
    }));
  };

  var filtercname = function filtercname(text) {
    var filter_text = text.trim();
    filter_text = filter_text.split("-");
    return filter_text[0];
  };

  var preferedclassname = function preferedclassname(classname) {
    if (classname == "1") {
      return "Any";
    } else if (classname == "2") {
      return "Business";
    } else if (classname == "3") {
      return "Economy";
    } else if (classname == "4") {
      return "First Class";
    } else if (classname == "5") {
      return "PremiumOrEconomy";
    } else if (classname == "6") {
      return "PremiumAndEconomy";
    }
  };

  var nonstopFlights = function nonstopFlights() {
    console.log("working");
    console.log(jsondata);
    console.log(jsondata.recommendation.filter(function (newdata) {
      return newdata.flightLeg[0].flightDetails.stopOvers == 0;
    }));
    console.log(jsondata);
  };

  var onChangeHome = function onChangeHome(id, suggestion, value) {
    console.log("onahnbeg vaue: ", value);

    if (id == "countries1") {
      var suggestion = suggestion.trim(); // setDepartureLocationName(suggestion);

      var length = suggestion.length;
      var exact_match = suggestion.substring(length - 4, length - 1);
      exact_match = exact_match.trim(); // setDeparturelocationcode(exact_match);
    } else if (id == "countries2") {
      var suggestion = suggestion.trim(); // setArrivalLocationName(suggestion);

      var length = suggestion.length;
      var exact_match = suggestion.substring(length - 4, length - 1);
      exact_match = exact_match.trim(); // setArrivallocationcode(exact_match);
    }
  };

  var currencyCode = jsondata.currencyCode;
  var total_response = jsondata.recommendation.length;
  return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(_components_layout__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 379
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "container-fluid",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 380
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "bg-img",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 381
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "margin-0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 382
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    style: {
      padding: '0'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 383
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-details",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 384
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 385
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xl: 3,
    lg: 4,
    md: 6,
    sm: 8,
    xs: 9,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 386
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 387
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 5,
    xs: 5,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 388
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-class",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 389
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text absl-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 390
    },
    __self: this
  }, "TRIP TYPE"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Control, {
    className: "trip_select",
    as: "select",
    defaultValue: requestData.searchType,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 391
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "1",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 392
    },
    __self: this
  }, "One Way"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "2",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 393
    },
    __self: this
  }, "Round Trip"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "3",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 394
    },
    __self: this
  }, "Multi-city")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-sort-desc",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 396
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 7,
    xs: 7,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 399
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "passanger-class",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 400
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text absl-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 401
    },
    __self: this
  }, "Passanger & Class"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 402
    },
    __self: this
  }, requestData.adultCount, " Adult, ", preferedclassname(requestData.preferedFlightClass)))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xl: 9,
    lg: 8,
    md: 6,
    sm: 4,
    xs: 3,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 409
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 412
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 6,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 413
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 414
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 6,
    sm: 6,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 415
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Group, {
    className: "auto_countries",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 416
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 417
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Prepend, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 418
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Text, {
    id: "inputGroupPrepend",
    className: "bluebg-igroup",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 419
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-map-marker",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 419
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(MyAutosuggest, {
    id: "countries1",
    onChange: onChangeHome,
    value: requestData.departureLocationName,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 421
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-exchange",
    "aria-hidden": "true",
    onClick: changePlace,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 424
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 6,
    sm: 6,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 426
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Group, {
    className: "auto_countries",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 427
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 428
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Prepend, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 429
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["InputGroup"].Text, {
    id: "inputGroupPrepend",
    className: "bluebg-igroup",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 430
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
    className: "fa fa-map-marker",
    "aria-hidden": "true",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 430
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(MyAutosuggest, {
    id: "countries2",
    onChange: onChangeHome,
    value: requestData.arrivalLocationName,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 432
    },
    __self: this
  })))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 6,
    className: "padding-col",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 438
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 439
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 8,
    md: 8,
    sm: 9,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 440
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "dis_flex",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 441
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "calendar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 442
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
    className: "img_calendar",
    src: "static/images/calendar.svg",
    width: "25",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 443
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_datepicker__WEBPACK_IMPORTED_MODULE_13__["default"], {
    name: "departureDate",
    className: "form-control",
    showMonthDropdown: true,
    showYearDropdown: true,
    dateFormat: "eee, MMM d",
    selected: startDate,
    onChange: handleChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 444
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "separt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 454
    },
    __self: this
  }, " | ")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "calendar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 456
    },
    __self: this
  }, "\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_datepicker__WEBPACK_IMPORTED_MODULE_13__["default"], {
    name: "departureDate",
    className: "form-control",
    showMonthDropdown: true,
    showYearDropdown: true,
    dateFormat: "eee, MMM d",
    selected: endDate,
    onChange: handleChange1,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 457
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 4,
    md: 4,
    sm: 3,
    xs: 12,
    className: "pad-6",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 470
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("button", {
    className: "btn-search",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 471
    },
    __self: this
  }, "SEARCH"))))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "mobile-filterscreen",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 482
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "visible-xs filter-mobile",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 483
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "filtering-row",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 484
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 6,
    xs: 6,
    lg: 6,
    style: {
      borderRight: '1px solid #FF4057'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 485
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    onClick: handlesortToggler,
    className: "mob-togglehead",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 486
    },
    __self: this
  }, "Sort ")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 6,
    xs: 6,
    lg: 6,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 488
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    onClick: handleFilterToggler,
    className: "mob-togglehead",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 489
    },
    __self: this
  }, "Filter "))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    style: {
      position: 'relative'
    },
    hidden: !sortToggler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 492
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    className: "sort",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 493
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 12,
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 494
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 495
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "bold-text",
    style: {
      fontSize: '13px'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 496
    },
    __self: this
  }, "Sort by:"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Button"], {
    variant: "outline-danger",
    style: {
      "float": 'right'
    },
    onClick: function onClick() {
      return _this2.setState({
        sortToggler: false,
        filterToggler: false
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 497
    },
    __self: this
  }, "Close")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("ul", {
    className: "mobile-sortlist",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 499
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 500
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 501
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Popularity",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 502
    },
    __self: this
  }), " Popularity")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 505
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 506
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Duration",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 507
    },
    __self: this
  }), " Duration")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("li", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 510
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 511
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("input", {
    className: "sort_name",
    type: "radio",
    name: "mobile_sorting",
    defaultValue: "Price",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 512
    },
    __self: this
  }), " Price"))))))), filterToggler ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "datas",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 522
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 523
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 524
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 525
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "bold-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 526
    },
    __self: this
  }, "Filter by:"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Button"], {
    variant: "outline-danger",
    style: {
      "float": 'right'
    },
    onClick: function onClick() {
      setSortToggler(false);
      setFilterToggler(false);
      setFilterToggler(false);
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 527
    },
    __self: this
  }, "Done")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 529
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 530
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 531
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 532
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 533
    },
    __self: this
  }, "Stops")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 536
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 537
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 538
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Non-stop",
    name: "stop1",
    value: "Non-stop",
    onClick: nonstopFlights,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 539
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "1stop",
    name: "stop2",
    value: "1stop",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 540
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "2 Stops",
    name: "stop3",
    value: "2stops",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 541
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 546
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 547
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 548
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 548
    },
    __self: this
  }, filtercname(requestData.departureLocationName)))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 551
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 552
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 553
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 554
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 555
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 556
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 561
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 562
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 563
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 563
    },
    __self: this
  }, filtercname(requestData.arrivalLocationName)))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 566
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 567
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 568
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 569
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 570
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 571
    },
    __self: this
  }))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 578
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 579
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 580
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 581
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 582
    },
    __self: this
  }, "Airlines"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 585
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 586
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 587
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 588
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Lingus(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 589
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Alitalia(6) 86,227",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 590
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Finance(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 591
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "American Airlines,102,750",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 592
    },
    __self: this
  }))))))))) : null), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter-data",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 609
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "container-fluid",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 610
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 611
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 10,
    xl: 10,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 612
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 613
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 3,
    className: "hidden-xs",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 615
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 616
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 617
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 618
    },
    __self: this
  }, "Stops"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 619
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 624
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 625
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 626
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Non-stop",
    name: "stop1",
    value: "Non-stop",
    onClick: nonstopFlights,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 627
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "1 Stop",
    name: "stop2",
    value: "1stop",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 628
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "2 Stops",
    name: "stop3",
    value: "2stops",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 629
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 634
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 635
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 636
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 636
    },
    __self: this
  }, filtercname(requestData.departureLocationName))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 637
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 641
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 642
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 643
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6 AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 644
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 645
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 646
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 651
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 652
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 653
    },
    __self: this
  }, "Departure from ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "filter-cname",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 653
    },
    __self: this
  }, filtercname(requestData.arrivalLocationName))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 654
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 658
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 659
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 660
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "6 AM - 12 Noon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 661
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "After 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 662
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "12 Noon - 6 PM",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 663
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_Set",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 668
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    className: "small_txt",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 669
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 670
    },
    __self: this
  }, "Airlines"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
    className: "pink-text",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 671
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 675
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 676
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "checkbox-custom",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 677
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Lingus(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 678
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Alitalia(6) 86,227",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 679
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "Aer Finance(2) 103,931",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 680
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Check, {
    type: "checkbox",
    label: "American Airlines,102,750",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 681
    },
    __self: this
  })))))), total_response > 0 ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 9,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 689
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 692
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 7,
    md: 7,
    sm: 5,
    xs: 6,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 693
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 694
    },
    __self: this
  }, total_response, " results sorted by ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 694
    },
    __self: this
  }, sortOption))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    lg: 5,
    md: 5,
    sm: 6,
    xs: 6,
    className: "text-right",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 696
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "select_box outline",
    style: {
      "float": 'right'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 697
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Form"].Control, {
    as: "select",
    name: "sortoptions",
    onChange: handleSortOptions,
    defaultValue: "Best",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 698
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "0",
    hidden: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 699
    },
    __self: this
  }, "Sort by"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Best",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 700
    },
    __self: this
  }, "Best"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Cheapest First",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 701
    },
    __self: this
  }, "Cheapest First"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Fastest First",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 702
    },
    __self: this
  }, "Fastest First"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Outbound: Departure Time",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 703
    },
    __self: this
  }, "Outbound: Departure Time"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Airline",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 704
    },
    __self: this
  }, "Airline"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("option", {
    value: "Stops",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 705
    },
    __self: this
  }, "Stops"))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "filter_sort",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 712
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 713
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 4,
    sm: 4,
    className: sortOption == "Best" ? 'filter_tab text-center active' : 'filter_tab text-center',
    "data-tip": true,
    "data-for": "best",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 714
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    onClick: handleSortBest,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 715
    },
    __self: this
  }, "Best", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 715
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 716
    },
    __self: this
  }, currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default()(currencyCode), " ", bestPrice()), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 717
    },
    __self: this
  }), bestDuration())), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_tooltip__WEBPACK_IMPORTED_MODULE_15___default.a, {
    id: "best",
    place: "top",
    type: "light",
    effect: "solid",
    "aria-haspopup": "true",
    role: "example",
    className: "tool",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 719
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }, "We think these flights offer the best combination of ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }, "price"), " and ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }, "speed"), ". We may also consider factors like ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 720
    },
    __self: this
  }), "number of stops and mount of hassle.")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 4,
    sm: 4,
    className: sortOption == "Cheapest First" ? 'filter_tab text-center active' : 'filter_tab text-center',
    "data-tip": true,
    "data-for": "cheapest",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 722
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    onClick: handleSortCheapest,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 723
    },
    __self: this
  }, "Cheapest", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 723
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 724
    },
    __self: this
  }, currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default()(currencyCode), " ", cheapestPrice()), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 725
    },
    __self: this
  }), cheapestDuration())), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_tooltip__WEBPACK_IMPORTED_MODULE_15___default.a, {
    id: "cheapest",
    place: "top",
    type: "light",
    effect: "solid",
    "aria-haspopup": "true",
    role: "example",
    className: "tool",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 727
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 728
    },
    __self: this
  }, "Sort by Cheatpest Price.")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 4,
    sm: 4,
    className: sortOption == "Fastest First" ? 'filter_tab text-center active' : 'filter_tab text-center',
    "data-tip": true,
    "data-for": "fastest",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 730
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    onClick: handleSortFastest,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 731
    },
    __self: this
  }, "Fastest", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 731
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 732
    },
    __self: this
  }, currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default()(currencyCode), " ", fastestPrice(), " "), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 733
    },
    __self: this
  }), fastestDuration())), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_tooltip__WEBPACK_IMPORTED_MODULE_15___default.a, {
    id: "fastest",
    place: "top",
    type: "light",
    effect: "solid",
    "aria-haspopup": "true",
    role: "example",
    className: "tool",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 735
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 736
    },
    __self: this
  }, "Sort by Shortest Duration.")))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "custom-container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 742
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "container",
    style: {
      padding: '0'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 743
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "sort-title d_flex",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 744
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 745
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 8,
    sm: 8,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 746
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("h3", {
    className: "bold-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 747
    },
    __self: this
  }, "Smart value Flights"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 748
    },
    __self: this
  }, "Popularity based on customer preference, duration & price")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    xs: 4,
    sm: 4,
    className: "text-right",
    style: {
      borderLeft: '1px solid #d5cece'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 750
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "topright-price",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 751
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("big", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 752
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "pink-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 752
    },
    __self: this
  }, "Chepeast Starting at")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 753
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
    className: "top-currency",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 754
    },
    __self: this
  }, currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default()(currencyCode), "\xA0", cheapestPrice()))))))), jsondata.recommendation.map(function (resultData) {
    var i = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      className: "sort-box",
      key: resultData.recommendationRefNo,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 768
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      sm: 9,
      style: {
        padding: '10px',
        borderRight: '1px dashed #03A9F4'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 769
      },
      __self: this
    }, resultData.totalFare == cheapestPrice() ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("button", {
      className: "pink-button cheap",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 770
      },
      __self: this
    }, "CHEAPEST") : react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("button", {
      className: "pink-button cheap",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 770
      },
      __self: this
    }, "VALUE FOR MONEY"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      className: "travel-timing",
      style: {
        marginTop: '6px'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 772
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      md: 12,
      sm: 12,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 773
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 774
      },
      __self: this
    }, "Departure"), " | ", dateformat__WEBPACK_IMPORTED_MODULE_16___default()(changeMonthDate(resultData.flightLeg[0].flightDetails.departureDate), "ddd, mmm d"), " | ", resultData.flightLeg[0].flightDetails.operatingAirlineName)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 777
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 3,
      sm: 4,
      className: "",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 778
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "sort-countryname",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 779
      },
      __self: this
    }, resultData.marketingAirlineNames)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 9,
      sm: 8,
      className: "flight-details",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 781
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 782
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 783
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "start-time text-right",
      htmlFor: "test" + i,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 784
      },
      __self: this
    }, TimeSplit(resultData.flightLeg[0].flightDetails.departureTime), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 786
      },
      __self: this
    }, resultData.flightLeg[0].flightDetails.departureLocationCode))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      className: "text-center",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 789
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "hrs",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 790
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 791
      },
      __self: this
    }, CalculateDuration(resultData.flightLeg[0].flightDetails.totalFlyingHours)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "line_jet",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 792
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: StopClassName(resultData.flightLeg[0].flightDetails.stopOvers),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 793
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "mini-text sky-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 794
      },
      __self: this
    }, StopName(resultData.flightLeg[0].flightDetails.stopOvers), " ", resultData.flightLeg[0].flightDetails.stopOvers > 0 ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 794
      },
      __self: this
    }, " via ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "via-city",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 794
      },
      __self: this
    }, ViaCityName(resultData.flightLeg[0].flightDetails.connectingFlightDetails[0].arrivalLocationName)), " ") : null), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
      className: "fa fa-fighter-jet autocomplete-flight-img",
      alt: "Flight",
      src: "static/images/flight.png",
      width: "16px",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 795
      },
      __self: this
    }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 798
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "start-time",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 799
      },
      __self: this
    }, TimeSplit(resultData.flightLeg[0].flightDetails.arrivalTime), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 801
      },
      __self: this
    }, resultData.flightLeg[0].flightDetails.arrivalLocationCode)))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      className: "travel-timing",
      style: {
        marginTop: '6px'
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 809
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      md: 12,
      sm: 12,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 810
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 811
      },
      __self: this
    }, "Return"), " | ", dateformat__WEBPACK_IMPORTED_MODULE_16___default()(changeMonthDate(resultData.flightLeg[1].flightDetails.departureDate), "ddd, mmm d"), " | ", resultData.flightLeg[1].flightDetails.operatingAirlineName)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 814
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 3,
      sm: 4,
      className: "",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 815
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "sort-countryname",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 816
      },
      __self: this
    }, resultData.marketingAirlineNames)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 9,
      sm: 8,
      className: "flight-details",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 818
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 819
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 820
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "start-time text-right",
      htmlFor: "test" + i,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 821
      },
      __self: this
    }, TimeSplit(resultData.flightLeg[1].flightDetails.departureTime), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 823
      },
      __self: this
    }, resultData.flightLeg[1].flightDetails.departureLocationCode))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      className: "text-center",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 826
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "hrs",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 827
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 828
      },
      __self: this
    }, CalculateDuration(resultData.flightLeg[1].flightDetails.totalFlyingHours)), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "line_jet",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 829
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: StopClassName(resultData.flightLeg[1].flightDetails.stopOvers),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 830
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "mini-text sky-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 831
      },
      __self: this
    }, StopName(resultData.flightLeg[1].flightDetails.stopOvers), resultData.flightLeg[1].flightDetails.stopOvers > 0 ? react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 831
      },
      __self: this
    }, " via ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "via-city",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 831
      },
      __self: this
    }, ViaCityName(resultData.flightLeg[1].flightDetails.connectingFlightDetails[0].arrivalLocationName)), " ") : null), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("img", {
      className: "fa fa-fighter-jet autocomplete-flight-img",
      alt: "Flight",
      src: "static/images/flight.png",
      width: "16px",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 832
      },
      __self: this
    }))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      xs: 4,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 835
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
      className: "start-time",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 836
      },
      __self: this
    }, TimeSplit(resultData.flightLeg[1].flightDetails.arrivalTime), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      className: "mini-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 838
      },
      __self: this
    }, resultData.flightLeg[1].flightDetails.arrivalLocationCode))))))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      sm: 3,
      className: "text-center set_bg",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 846
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "sort-currency",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 847
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "deals_no",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 848
      },
      __self: this
    }, "8 deals"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("br", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 850
      },
      __self: this
    }), currency_symbol_map__WEBPACK_IMPORTED_MODULE_17___default()(jsondata.currencyCode), "\xA0", resultData.totalFare), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_26___default.a, {
      href: {
        pathname: 'ticketdetails',
        query: {
          id: resultData.recommendationRefNo
        }
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 857
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("button", {
      className: "bpk-button",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 858
      },
      __self: this
    }, "Select ", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
      className: "fa fa-arrow-right",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 858
      },
      __self: this
    })))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      className: "flight-details",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 861
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      sm: 12,
      className: "text-center grey",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 862
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 863
      },
      __self: this
    }, "Cabin Baggage Only Flights"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
      className: "flight-details bottom",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 866
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
      sm: 8,
      xs: 7,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 867
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 868
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
      className: "fa fa-star",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 869
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("b", {
      className: "green-text",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 870
      },
      __self: this
    }, "8.5", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("small", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 870
      },
      __self: this
    }, "/10")), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      className: "",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 871
      },
      __self: this
    }, " Non-refundable"), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("i", {
      className: "fa fa-angle-down",
      "aria-hidden": "true",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 872
      },
      __self: this
    }), " |", react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("span", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 873
      },
      __self: this
    }, "Seat varies by flight segment")))));
  })) : react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("center", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 881
    },
    __self: this
  }, "No data found"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    sm: 12,
    md: 12,
    lg: 2,
    xl: 2,
    className: "text-center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 887
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Row"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 888
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 889
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 890
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 891
    },
    __self: this
  }, "Place for ad"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 894
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 895
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 896
    },
    __self: this
  }, "Place for ad"))), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__["Col"], {
    md: 4,
    lg: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 899
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
    className: "ad-block",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 900
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 901
    },
    __self: this
  }, "Place for ad"))))))))));
}; // TicketBooking.getInitialProps = ({ query: { departureLocationCode,arrivalLocationCode,departureDate,returnDate,isDirectFlight,searchType,adultCount,childCount,preferedFlightClass,departureTime,returnTime,departureLocationName,arrivalLocationName} }) => {
//     return { 
//         departureLocationCode: departureLocationCode, 
// 		arrivalLocationCode: arrivalLocationCode, 
//         departureDate: departureDate,
//         returnDate: returnDate,
//         isDirectFlight : isDirectFlight,
//         searchType: searchType,
//         adultCount: adultCount,
//         childCount: childCount,
//         preferedFlightClass: preferedFlightClass,
//         departureTime: "Any",
//         returnTime: "Any",
//         departureLocationName: departureLocationName,
//         arrivalLocationName: arrivalLocationName
//      }
//   }


TicketBooking.getInitialProps =
/*#__PURE__*/
function () {
  var _ref5 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref4) {
    var _ref4$query, adultCount, childCount, infantCount, isDirectFlight, isPlusOrMinus3Days, searchType, preferedFlightClass, departureLocationCode, departureDate, arrivalLocationCode, returnDate, departureTime, returnTime, PageIndex, PageSize, departureLocationName, arrivalLocationName, request, res, json;

    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _ref4$query = _ref4.query, adultCount = _ref4$query.adultCount, childCount = _ref4$query.childCount, infantCount = _ref4$query.infantCount, isDirectFlight = _ref4$query.isDirectFlight, isPlusOrMinus3Days = _ref4$query.isPlusOrMinus3Days, searchType = _ref4$query.searchType, preferedFlightClass = _ref4$query.preferedFlightClass, departureLocationCode = _ref4$query.departureLocationCode, departureDate = _ref4$query.departureDate, arrivalLocationCode = _ref4$query.arrivalLocationCode, returnDate = _ref4$query.returnDate, departureTime = _ref4$query.departureTime, returnTime = _ref4$query.returnTime, PageIndex = _ref4$query.PageIndex, PageSize = _ref4$query.PageSize, departureLocationName = _ref4$query.departureLocationName, arrivalLocationName = _ref4$query.arrivalLocationName;
            request = {
              "adultCount": adultCount,
              "childCount": childCount,
              "infantCount": infantCount,
              "isDirectFlight": isDirectFlight,
              "isPlusOrMinus3Days": isPlusOrMinus3Days,
              "searchType": searchType,
              "preferedFlightClass": preferedFlightClass,
              "segments": [{
                "departureLocationCode": departureLocationCode,
                "departureDate": departureDate,
                "arrivalLocationCode": arrivalLocationCode,
                "returnDate": returnDate,
                "departureTime": departureTime,
                "returnTime": returnTime
              }],
              "paging": {
                "PageIndex": PageIndex,
                "PageSize": PageSize
              }
            };
            _context.next = 4;
            return Object(_api__WEBPACK_IMPORTED_MODULE_22__["getFlights"])(request);

          case 4:
            res = _context.sent;
            _context.next = 7;
            return res;

          case 7:
            json = _context.sent;
            return _context.abrupt("return", {
              flights: json,
              request: {
                "adultCount": adultCount,
                "childCount": childCount,
                "infantCount": infantCount,
                "isDirectFlight": isDirectFlight,
                "isPlusOrMinus3Days": isPlusOrMinus3Days,
                "searchType": searchType,
                "preferedFlightClass": preferedFlightClass,
                "departureLocationName": departureLocationName,
                "arrivalLocationName": arrivalLocationName,
                "segments": [{
                  "departureLocationCode": departureLocationCode,
                  "departureDate": departureDate,
                  "arrivalLocationCode": arrivalLocationCode,
                  "returnDate": returnDate,
                  "departureTime": departureTime,
                  "returnTime": returnTime
                }],
                "paging": {
                  "PageIndex": PageIndex,
                  "PageSize": PageSize
                }
              }
            });

          case 9:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref5.apply(this, arguments);
  };
}();

/* harmony default export */ __webpack_exports__["default"] = (TicketBooking);

/***/ })

})
//# sourceMappingURL=ticketBooking.js.30b01c7374dcab3cea9c.hot-update.js.map