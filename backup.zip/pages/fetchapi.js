import React from 'react';

import axios from 'axios';

export default class Fetchapi extends React.Component {
  state = {
    persons: []
  }



  componentDidMount() {
    let url = 'https://pln.lycafly.com/Affiliate/Flight/Aw_SearchFlight';
    let headers = new Headers({'Authorization': 'Basic 0b017b0c0d414e20ee0d2e4adbed686d7c297a6d2f8ec8f9eddc2016d9513482a086fe8712ef0530',
                                 'content-Type': 'application/json'});
    axios.get(url,{method: 'POST',header: headers})
      .then(res => {
        const persons = res.data;
        this.setState({ persons });
        console.log(persons);
      })
  }

  render() {
    return (
      <ul>
        {/* { this.state.persons.map(person => <li>{person.me}</li>)} */}
        <li>Test</li>
      </ul>
    )
  }
}