import React,{Component} from 'react';
import { connect } from 'react-redux'
import { getFlights } from '../lib/actions';


const imgStyle = {
  hight: 'auto',
  width: '80%',
  border: '4px solid RebeccaPurple ',
  borderRadius: '5%'
};
const articleStyle = {
width: '50%',
margin: '0 auto',
color: 'olive'
}
class NewsItem extends Component
{
// getFlights()
// {
//   console.log("working");
// }
render()
{
var article = this.props.article;
return(
<div>
  <button onClick={this.props.getFlights}>Press to see news</button>
{article ?
<article style={articleStyle} >
  <div>
    <h1>{article.currencyCode}</h1>
    {/* <img style={imgStyle} src={article.urlToImage} alt="" /> */}
    <h4>{article.adultCount}</h4>
    <a href={article.url} target="_blank">READ MORE</a>
  </div>
</article> :
null }
</div>);
} }

// NewsItem.getInitialProps = async ({ store }) => {
//     store.dispatch(getFlights());
//  }

const mapStateToProps = (state) => ({
article: state.flights,
})
const mapDispatchToProps = {
  getFlights: getFlights,
};
NewsItem = connect(mapStateToProps,mapDispatchToProps)(NewsItem)
export default NewsItem;